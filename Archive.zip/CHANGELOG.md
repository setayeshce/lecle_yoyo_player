## 0.0.1

* Initial release.

## 0.0.2

* Update cache file location on iOS.

## 0.0.3

* Update Flutter version
* Fix pub error

## 0.0.3+1

* Fix pub error

## 0.0.4

* Add missed properties and method call
* Update some methods logic
* Update document for permission request

## 0.0.4+1

* Update document
* Remove redundant code

## 0.0.5

* Add live direct button for live video feature
* Update document

## 0.0.5+1

* Add enable and disable system's orientation override feature
* Update document

## 0.0.5+2

* Fix video player show loading after change m3u8 video quality issue

## 0.0.6

* Updates minimum Flutter version to 3.10

## 0.0.7
* Upgrade all package to newest version

## 0.0.8
* Update old package to new version
