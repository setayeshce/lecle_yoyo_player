/// Audio model to save the audio's path
class AudioModel {
  /// The url of the video
  final String? url;

  /// Constructor
  AudioModel({this.url});
}
